const mongoose = require('mongoose');
const initData=require('./data.js');

const Listing =require("../models/Listing");

async function main(){
   mongoose.connect("mongodb:database likn");
}

main().then(()=>{
    console.log("intilized the database");
}).catch(err=>{
    console.log("Failed to intilized the database");
})

const initDB=async function(){
   await Listing.deleteMany({});
   await Listing.insertMany(initData.data);
   console.log("data was intitalized");
}
initDB();


